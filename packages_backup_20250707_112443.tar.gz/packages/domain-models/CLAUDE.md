# Domain Models Package

Single source of truth for DiPeO domain models, automatically generating Python, GraphQL, and other formats from TypeScript definitions.

## Overview

This package defines the core domain models for the DiPeO system in TypeScript and provides code generation scripts to create consistent models in multiple languages and formats.

## Key Models

- **Diagram Models** (`diagram.ts`): Core diagram structure including nodes, arrows, handles, and persons
- **Execution Models** (`execution.ts`): Execution state, status tracking, and token usage
- **Conversation Models** (`conversation.ts`): Message formats and conversation state
- **Integration Models** (`integration.ts`): External service configurations (LLM, Notion, etc.)

## Generated Outputs

```bash
pnpm generate:all  # Generates all formats
```

Generates:
- **Python Models** → `packages/python/dipeo_domain/src/dipeo_domain/models.py`
- **CLI Models** → `apps/cli/src/dipeo_cli/__generated__/models.py`
- **Conversions** → `packages/python/dipeo_domain/src/dipeo_domain/conversions.py`

Note: GraphQL schema is now generated directly from the Python Strawberry server at `apps/server/schema.graphql`

## Usage

### Adding New Models

1. Define models in appropriate TypeScript file under `src/`
2. Run `pnpm build` to generate all formats
3. Models are automatically available in Python and other targets

### Model Guidelines

- Use interfaces for data structures
- Use enums for fixed value sets
- Include JSDoc comments for documentation
- Use branded types for IDs (e.g., `NodeID`, `PersonID`)

### Example

```typescript
// In src/diagram.ts
export interface DomainNode {
  id: NodeID;
  type: NodeType;
  position: Vec2;
  data: Record<string, any>;
}
```

Automatically generates Python:
```python
class DomainNode(BaseModel):
    id: NodeID
    type: NodeType
    position: Vec2
    data: Dict[str, Any]
```