# This package has been moved

The domain-models package has been relocated to:

**New location: `dipeo/models/`**

Please update your references:
- `packages/domain-models` → `dipeo/models`

The package.json scripts and all functionality remain the same in the new location.